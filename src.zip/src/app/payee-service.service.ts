import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payee } from './payee-menu/Payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeServiceService {

  baseUrl:String=""
  constructor(private myHttp:HttpClient) { 
  }

  addPayeeService(payeeToAdd:Payee){
    this.myHttp.post(this.baseUrl+"/addPayee",payeeToAdd);
  }
  getPayeeService(payeeAcc:number) : Observable<Payee>{
    return this.myHttp.get<Payee>(this.baseUrl+"/getPayee"+payeeAcc);
  }
  deletePayeeService(pId:number){
    this.myHttp.delete(this.baseUrl+"/removePayee"+pId);
  }
}
