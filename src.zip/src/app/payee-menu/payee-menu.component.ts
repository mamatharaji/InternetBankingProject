import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Payee } from './Payee';

@Component({
  selector: 'app-payee-menu',
  templateUrl: './payee-menu.component.html',
  styleUrls: ['./payee-menu.component.css']
})
export class PayeeMenuComponent implements OnInit {
  payeeType:String="";
  show:boolean=false;
  v:boolean=false;
  a:boolean=false;
  d:boolean=false;
  id:number=0;
  errorMsg:string="";
  error:Boolean=false;
  confirmAcc:number=0;
  constructor() { }
  menuIdentifier:string="";
  payee:Payee = new Payee();
  payeeArray:Payee[]=[];

  ngOnInit(): void {
  }
  showView(){
    this.v=true;
    this.a=false;
    this.d=false;
  }
  showAdd(){
    this.a=true;
    this.d=false;
    this.v=false;
  }
  showDelete(){
    this.d=true;
    this.a=false;
    this.v=false;
  }

  toggleIfsc(){
    console.log("toggle");
    console.log(this.payeeType);
    console.log(this.menuIdentifier);
    if(this.payeeType==="Own Bank Account"){
        this.show=false;
    }
    else if(this.payeeType==="Other Bank Account"){
      this.show=true;
    }
    
  }
  deletePayee(payeeToDelete:Payee){
    console.log("deletePayee()");
    this.payeeArray=this.payeeArray.filter(item=> item!=payeeToDelete);
  }
  addPayee(){
    this.payeeArray.push(this.payee);
  }
  validateAcc(){
    if(this.payee.payeeAccountNumber!=this.confirmAcc){
      this.errorMsg="Account Number does not match";
      this.error=true;
    }
    else{
      this.error=false;
    }
  }

}
