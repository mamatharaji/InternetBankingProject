export class Payee{
    payeeName:string="";
    payeeAccountNumber:number=0;
    nickName:string="";
    accountNumber:number=0;
}