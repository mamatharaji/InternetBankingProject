package com.sbi.project;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Payee;
import com.sbi.project.layer3.PayeeRepoImpl;
import com.sbi.project.layer3.PayeeRepository;

@SpringBootTest
public class PayeeRepoTesting {
	
	@Autowired
	PayeeRepository payeeRepo;
	
	@Test
	public void payeeLoadingRepotest(){
		List<Payee> payeeList=payeeRepo.findAllPayee(10001);
		for (Payee payee : payeeList) {
			payee.getPayeeName();
		}
		
	}

}
