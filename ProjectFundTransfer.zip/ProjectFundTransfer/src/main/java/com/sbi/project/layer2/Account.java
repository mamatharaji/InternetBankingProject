package com.sbi.project.layer2;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="project_account")
public class Account {

	@Id
	@Column(name="account_number")
	private Integer accountNumber;
	private String password;
	private Float balance;
	@OneToOne
	@JoinColumn(name="applicant_id")
	Applicant applicant;

}

