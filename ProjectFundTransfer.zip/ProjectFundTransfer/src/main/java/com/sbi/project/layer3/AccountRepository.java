package com.sbi.project.layer3;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Account;

@Repository
public interface AccountRepository {

	Account getAccount(int accountNumber);
	void setAccount(Account account);
}
