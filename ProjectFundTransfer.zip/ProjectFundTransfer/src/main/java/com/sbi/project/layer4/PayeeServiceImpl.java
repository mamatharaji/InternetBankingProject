package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Payee;
import com.sbi.project.layer3.PayeeRepository;
@Service
public class PayeeServiceImpl implements PayeeService {

	
	@Autowired
	PayeeRepository payeeRepo;
	
	@Override
	public void addPayeeService(Payee payeeObj) {
		payeeRepo.addPayee(payeeObj);
		

	}

	@Override
	public void deletePayeeService(int payeeId) {
		payeeRepo.deletePayee(payeeId);

	}

	@Override
	public Payee findPayee(int payeeId) {
		
		return payeeRepo.findPayee(payeeId);
	}

	@Override
	public List<Payee> findAllPayee(int accountNumber) {

		return payeeRepo.findAllPayee(accountNumber);
	}

}
